import pandas as pd
from kiteconnect import KiteConnect

# --- 1. CONFIGURATION ---
API_KEY = "3pjrl664qozljcaw"
API_SECRET = "6uggnaxpi62fzz9l8ntu86iv9fhbh5cv"

# --- 2. AUTHENTICATION ---
kite = KiteConnect(api_key=API_KEY)

print("1. Open this URL in your browser to log in:")
print(kite.login_url())
print("-" * 50)

request_token = input("2. Enter the 'request_token' from the redirected URL: ").strip()

try:
    session_data = kite.generate_session(request_token, api_secret=API_SECRET)
    kite.set_access_token(session_data["access_token"])
    print("\nAuthentication Successful!\n")
except Exception as e:
    print(f"Authentication Failed: {e}")
    exit()

# --- 3. FETCH NSE SMALLCAP 250 LIST VIA PUBLIC MIRROR ---
print("Fetching official NSE Smallcap 250 list from live data mirror...")
try:
    # Stable public mirror for Nifty index constituents
    mirror_url = "https://raw.githubusercontent.com/anirban-m/nifty-indices-constituents/main/ind_nifty_smallcap_250list.csv"
    nse_smallcap_df = pd.read_csv(mirror_url)
    smallcap_symbols = nse_smallcap_df['Symbol'].str.strip().tolist()
    print(f"Successfully loaded {len(smallcap_symbols)} smallcap symbols from index.")
except Exception as e:
    print(f"Error fetching the index list mirror: {e}")
    exit()

# --- 4. FETCH ALL INSTRUMENTS FROM ZERODHA ---
print("Fetching instrument list from Zerodha Kite...")
instruments = kite.instruments(exchange="NSE")
kite_df = pd.DataFrame(instruments)

# Filter out only standard Equities (EQ)
kite_equities = kite_df[kite_df['instrument_type'] == 'EQ']

# --- 5. FILTER SMALL CAP STOCKS & SAVE ---
print("Filtering Small-Cap stocks and generating final CSV...")

# Filter Zerodha's instrument list based on the NSE Smallcap symbols
small_cap_details = kite_equities[kite_equities['tradingsymbol'].isin(smallcap_symbols)]

# Export the columns to a CSV
output_file = "zerodha_smallcap_stocks.csv"
small_cap_details.to_csv(output_file, index=False)

print(f"\nSuccess! Found {len(small_cap_details)} matching Small Cap stocks.")
print(f"Your file has been saved as: {output_file}")